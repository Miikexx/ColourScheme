##### Final Project CMPT 120 // Function Definitions
# Names: Erica Hui (#301453320), Mike Kim (#301459116)
# Date: March 30, 2022

# importing modules and file setup
import csv
import copy as cm
import cmpt120image
file = open("colours.csv")
data = csv.reader(file)

#lists and dicts
colourList = []
fullColourList = []
fullRGBList = []
RGBList = []

fullDict = {}
incompleteDict = {}
fullComboNameHex = []
ListRGB = []
ListHex = []
RGBinList = []

#option one
def rgb2hex(rgbList): #converts rgb to hex
    for c in rgbList:
        hR = hex(int(rgbList[0]))
        hG = hex(int(rgbList[1]))
        hB = hex(int(rgbList[2]))
        if len(hR) <4:
            if hR == "0x0":
                hR = hR.strip("0x")
                hR = "00"
            else:
                hR = hR.strip("0x")
                hR = "0" + hR.upper()
        else:
            hR = hR.lstrip("0x").upper()
        if len(hG) <4:
            if hG == "0x0":
                hG = hG.strip("0x")
                hG = "00"
            else:
                hG = hG.strip("0x")
                hG = "0" + hG.upper()
        else:
            hG = hG.lstrip("0x").upper()
        if len(hB) <4:
            if hB == "0x0":
                hB = hB.strip("0x")
                hB = "00"
            else:
                hB = hB.strip("0x")
                hB = "0" + hB.upper()
        else:
            hB = hB.lstrip("0x").upper()
        hRGB = ("#" + hR + hG + hB)
    return hRGB

for initial in file:
    i = initial.strip("\n").split(",")
    colourList = colourList + [i[1]]
    colourList = ([int(i) for i in colourList])
    colourCount = (len(colourList))
    colourName = i[0]
    r = int(i[1])
    g = int(i[2])
    b = int(i[3])
    fullRGBList = (r, g, b)
    ListRGB.append(fullRGBList) #list of rgb in tuple form
    RGBsquare = [r, g, b]
    RGBinList.append(RGBsquare) #list of rgb in list form
    fullColourList = (colourName, r, g, b)
    hexCall = rgb2hex(fullRGBList)
    ListHex.append(hexCall) #list of all hex codes
    comboNameHex = [colourName, hexCall]
    fullComboNameHex.append(comboNameHex) #list of name and relevant hex
    incompleteDict = {fullRGBList:comboNameHex} #dictionary with rgb key and colourname/hex values
    for key in incompleteDict:
        if key not in fullDict: #fullDict is the complete dictionary, no duplicates
            fullDict[key] = incompleteDict[key] #adds nonexisting keys and values to dict

dictKeysCount = len(fullDict) #number of entries/keys in dict
  
print("The file has been processed and", colourCount, "colours were added to the dictionary.") #sample has 10 colours

#option two
def optionTwo():
  
  # Table Setup
  print("{:<40} {:<10} {:<10} {:<10} {:<10} ".format('Colour Name','Red','Green','Blue','Hex'))
  print("{:<40} {:<10} {:<10} {:<10} {:<10} ".format('-----------','-----','-----','-----','-------'))
  # setting up lists and opening file
  file = open("colours.csv")
  ultimate_list = []
  concatenated_list = []
  
  for line in file:
    line = line.strip().split(",")
    
    # Red value + hexadecimal conversion 
    red_hex = hex(int(line[1]))
    hexone = str(red_hex).upper()
    if len(hexone) == 4: 
      hexone = "#" + hexone[2:]
    if len(hexone) == 3:
      if hexone[0] == "0":
        hexone = "#0" + hexone[2:]
      else:
        hexone = ("#" +hexone[1:])
    updated_one = hexone
    
    # Green value + hexadecimal conversion
    green_hex = hex(int(line[2]))
    hextwo = str(green_hex).upper()
    if len(hextwo) == 4: 
      hextwo = hextwo[2:]
    if len(hextwo) == 3:
      hextwo = "0" + hextwo[2:]
    updated_two  = hextwo
    
    # Blue value + hexadecimal convesion
    blue_hex = hex(int(line[3]))
    hexthree = str(blue_hex).upper()
    if len(hexthree) == 4: 
      hexthree = hexthree[2:]
    if len(hexthree) == 3:
      hexthree = "0" + hexthree[2:]
    updated_three = hexthree
    
    concatenated_list += [updated_one+updated_two+updated_three]
    
    # big list that contains all data
    ultimate_list += [line[0],line[1],line[2], line[3],updated_one+updated_two+updated_three]
  # re - reading process
  file.seek(0)
  for line in file:
    line = line.strip().split(",")
    # Accumulators to call out the proper value
    nameTally = 0
    rTally = 0
    gTally = 0
    bTally = 0
    hextally = 0

  # Filling the table in a neat manner
  for i in range(len(concatenated_list)):
    print("{:<40} {:<10} {:<10} {:<10} {:<10}".format(ultimate_list[0+nameTally].capitalize(), \
                                                      ultimate_list[1+rTally],ultimate_list[2+gTally],ultimate_list[3+bTally],\
                                                      ultimate_list[4+hextally])) 
    
  
    nameTally += 5
    rTally += 5
    gTally += 5
    bTally += 5
    hextally += 5
  file.seek(0)

# Option Three
def optionThree():
  colourNameList = []
  two_options =  ("1. Enter a name for this colour" "\n" "2. Return to the main menu   " "\n" "Type here: " )
  matching_true = ""

  # collecting info from user and making a list out of it
  print("Enter the RGB values of your colour")
  user_red = (input("R: "))
  user_green = (input("G: "))
  user_blue = (input("B: "))
  user_rgb_list = [user_red, user_green, user_blue]
  
  # getting the rgb values from the list
  file = open("colours.csv")
  csv_final_list = []
  colourNameList = []
  for line in file:
    line = line.strip().split(",")
    csv_rgb_list = [(line[1]),(line[2]),(line[3])]
    csv_final_list.append(csv_rgb_list)
  # accumulator setup
  colourtally = 0

  file.seek(0)

  # setup variables
  matching_true_1 = ""
  matching_true_2 = ""
  matching_true_3 = ""
  unmatching_tally = 0
  # checking whether if the input matches the colour list (csv file)
  for line in file:
    line = line.strip().split(",")
    colourNameList.append(line[0])
  for i in range(len(colourNameList)):
    # when colour is found
    if user_rgb_list == csv_final_list[i]:
      matching_true_1 = (csv_final_list[i])
      matching_true_2 = colourNameList[i].capitalize()
      matching_true_3 = rgb2hex(csv_final_list[i])
      colourtally +=1
    # when colour isn't found
    else:
      matching_false =  user_rgb_list 
  
      
      
  if colourtally >= 1:
    matched_colour = print("Colour" , matching_true_1 , "is" , matching_true_2 , "and has a hex code " , matching_true_3 , ".")
    matched_colour
  

  if colourtally == 0:
      
    print("Colour" , matching_false, " is not found. Would you like to: ")
      
    two_options = int(input(two_options))
    two_options
    
  # when sample not found: 
  if two_options == 1:
    user_colour_name = input("What is the colours name? ").lower()
    unmatching_tally = 0
    file = open("colours.csv")
    for line in file:
      line = line.strip().split(",")
      colourNameList.append(line[0])
    for i in range(len(colourNameList)): 
      if user_colour_name == colourNameList[i]:
        matchRGB = [line[1],line[2],line[3]]
      
        matching_occasion = print("Colour " , matchRGB, " is ", user_colour_name.capitalize()," and has hex code " , rgb2hex(matchRGB), ".") 
        #matching_occasion
    if user_colour_name != colourNameList[i]:
          
        unmatching_occasion = print("Colour ", user_rgb_list, "is ",user_colour_name, " and has hex code " , rgb2hex(user_rgb_list))
        unmatching_tally += 1
  elif unmatching_tally < 0: #
      matching_occasion
  elif unmatching_tally >= 1:
      unmatching_occasion
  elif two_options == 2:
    print("Ok returning to main menu...")
  
  

# option four
def optionFour():
    print("Enter the RGB values of your colour.")
    userR = int(input("R: "))
    userG = int(input("G: "))
    userB = int(input("B: "))
    userRGB = (userR, userG, userB) #inputed RGB
    userRGBList = [userR, userG, userB] #inputed RGB with []

    abList = []
    
    for elem in RGBinList:
        absR = abs(userR - (int(elem[0])))
        absG = abs(userG - (int(elem[1])))
        absB = abs(userB - (int(elem[2])))
        absSum = absR + absG + absB
        abList.append(absSum) #all abs values

    minABS = abList[0]

    if userRGB in fullDict:
        print("Colour", userRGBList, "is", fullDict[userRGB][0],
        "and has hex code", fullDict[userRGB][1] + ".")
    else:
        for smallABS in range(len(abList)):
            if abList[smallABS]<minABS:
                minABS = abList[smallABS] #the smallest abs difference
                minABSindex = abList.index(minABS) #index of minABS
        print("The closest colour to", userRGBList, "is", fullComboNameHex[minABSindex][0], "with hex code", fullComboNameHex[minABSindex][1] + ".")  
        print("The absolute difference between the two colours is", minABS, ".")

# option five
def optionFive():
    print("Enter the RGB values of your colour.")
    userR = int(input("R: "))
    userG = int(input("G: "))
    userB = int(input("B: "))
    userRGB = [userR, userG, userB]
    print()
    print("Which colour scheme do you wish to display?\n"
        "M: Monochrome\n"
        "C: Complementary")
    print()
    userScheme = (input("Select an option: ")).upper()

    compR = 255 - userR
    compG = 255 - userG
    compB = 255 - userB
    compRGB = [compR, compG, compB]

    def lighten(colour):
        light1 = [(colour[0] + (255 - colour[0]) * 0.8), (colour[1] + (255 - colour[1]) * 0.8), (colour[2] + (255 - colour[2]) * 0.8)] #lightest
        light2 = [(colour[0] + (255 - colour[0]) * 0.5), (colour[1] + (255 - colour[1]) * 0.5), (colour[2] + (255 - colour[2]) * 0.5)]
        lightList = [light1, light2]
        return lightList

    def darken(colour):
        dark1 = [colour[0] * 0.5, colour[1] * 0.5, colour[2] * 0.5] #darkest
        dark2 = [colour[0] * 0.8, colour[1] * 0.8, colour[2] * 0.8]
        darkList = [dark1, dark2]
        return darkList

    img240 = cmpt120image.getBlackImage(240, 240)
    img480 = cmpt120image.getBlackImage(480, 240)
    lightCall = lighten(userRGB)
    darkCall = darken(userRGB)
    lightCallC = lighten(compRGB)
    darkCallC = darken(compRGB)

    def monochrome(image):
      monoCopy = cm.deepcopy(image)
      for row in range(0, 80):
        for col in range(0, 80):
          monoCopy[row][col] = lightCall[0]
      for row in range(160, 240):
        for col in range(0, 80):
          monoCopy[row][col] = darkCall[0]
      for row in range(0, 80):
        for col in range(160, 240):
          monoCopy[row][col] = lightCall[1]
      for row in range(160, 240):
        for col in range(160, 240):
          monoCopy[row][col] = darkCall[1]
      for row in range(80, 160):
        for col in range(0, 240):
          monoCopy[row][col] = userRGB
      for row in range(0, 240):
        for col in range(80, 160):
          monoCopy[row][col] = userRGB
      return monoCopy
    
    def complementary(comp):
      compCopy = cm.deepcopy(img480)
      compCopy = monochrome(img480) #main colour squares
      #complementary colour squares
      for row in range(0, 80):
        for col in range(240, 320):
          compCopy[row][col] = lightCallC[0]
      for row in range(160, 240):
        for col in range(240, 320):
          compCopy[row][col] = darkCallC[0]
      for row in range(0, 80):
        for col in range(400, 480):
          compCopy[row][col] = lightCallC[1]
      for row in range(160, 240):
        for col in range(400, 480):
          compCopy[row][col] = darkCallC[1]
      for row in range(80, 160):
        for col in range(240, 480):
          compCopy[row][col] = compRGB
      for row in range(0, 240):
        for col in range(320, 400):
          compCopy[row][col] = compRGB
      return compCopy
    
    if userScheme == "M":
      Mcall = monochrome(img240)
      cmpt120image.saveImage(Mcall,"csscheme.png")
    elif userScheme == "C":
      Ccall = complementary(img480)
      cmpt120image.saveImage(Ccall, "csscheme.png")

#end program