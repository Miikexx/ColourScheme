# Final project: Colour Schemes Main Program
# Name: Erica Hui (#301453320), Mike Kim (#301459116)
# Section: D100 (For both students)
# Group Number: #147
# Date: March 30th, 2022

# importing modules
import cmpt120image
import cmpt120colours

# main menu
print("1. Load Colour File")
print("2. Print All Colours")
print("3. Select Colour")
print("4. Find Closest colour")
print("5. Display (Save) Colour Scheme")
print("0. Quit")
print()

# main menu loop

# declare boolean
notzero = True

while (notzero == True):
    enter_num = int(input("Enter 1 to 5, 0 to quit: "))
    # Output scenarios
    if enter_num == 0:
        print("The program will be quitting.")
        notzero = False

    elif enter_num == 1:
        newColourCount = cmpt120colours.dictKeysCount
        print("This file has been processed and", newColourCount,
              "colours were added to the dictionary.")
    elif enter_num == 2:
        cmpt120colours.optionTwo()
    elif enter_num == 3:
        cmpt120colours.optionThree()
    elif enter_num == 4:
        cmpt120colours.optionFour()
    elif enter_num == 5:
        cmpt120colours.optionFive()
    else:
        print("Please enter a number between 0 and 5.")
